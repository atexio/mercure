#!/bin/bash

echo "{
\"tracker_url\": \"$TRACKER_URL\",
\"target_email\": \"$TARGET_EMAIL\",
\"target_first_name\": \"$TARGET_FIRST_NAME\",
\"target_last_name\": \"$TARGET_LAST_NAME\"
}" | base64